#include "relocate.h"
#define relocate(path) relocatep(path)
