/* Generated automatically by Makefile.PL. Do not edit */
#define HAVE_DGETTEXT
#define HAVE_NGETTEXT
#define HAVE_BIND_TEXTDOMAIN_CODESET
